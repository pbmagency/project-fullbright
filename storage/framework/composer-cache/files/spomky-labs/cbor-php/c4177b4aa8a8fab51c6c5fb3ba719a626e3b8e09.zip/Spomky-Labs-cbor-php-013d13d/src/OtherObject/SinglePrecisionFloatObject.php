<?php

declare(strict_types=1);

namespace CBOR\OtherObject;

use Brick\Math\BigInteger;
use CBOR\Normalizable;
use CBOR\OtherObject as Base;
use CBOR\Utils;
use const INF;
use InvalidArgumentException;
use const NAN;
use function strlen;

final class SinglePrecisionFloatObject extends Base implements Normalizable
{
    public static function supportedAdditionalInformation(): array
    {
        return [self::OBJECT_SINGLE_PRECISION_FLOAT];
    }

    public static function createFromFloat(float $number): self
    {
        $value = match (true) {
            is_nan($number) => self::hex2binSafe('7FC00000'),
            is_infinite($number) && $number > 0 => self::hex2binSafe('7F800000'),
            is_infinite($number) && $number < 0 => self::hex2binSafe('FF800000'),
            default => (static fn (): string => unpack('S', "\x01\x00")[1] === 1 ? strrev(pack('f', $number)) : pack(
                'f',
                $number
            ))(),
        };

        return new self(self::OBJECT_SINGLE_PRECISION_FLOAT, $value);
    }

    public static function createFromLoadedData(int $additionalInformation, ?string $data): Base
    {
        return new self($additionalInformation, $data);
    }

    public static function create(string $value): self
    {
        if (strlen($value) !== 4) {
            throw new InvalidArgumentException('The value is not a valid single precision floating point');
        }

        return new self(self::OBJECT_SINGLE_PRECISION_FLOAT, $value);
    }

    public function normalize(): float|int
    {
        $exponent = $this->getExponent();
        $mantissa = $this->getMantissa();
        $sign = $this->getSign();

        if ($exponent === 0) {
            $val = $mantissa * 2 ** (-(126 + 23));
        } elseif ($exponent !== 0b11111111) {
            $val = ($mantissa + (1 << 23)) * 2 ** ($exponent - (127 + 23));
        } else {
            $val = $mantissa === 0 ? INF : NAN;
        }

        return $sign * $val;
    }

    public function getExponent(): int
    {
        $data = $this->data;
        Utils::assertString($data, 'Invalid data');

        return Utils::binToBigInteger($data)->shiftedRight(23)->and(Utils::hexToBigInteger('ff'))->toInt();
    }

    public function getMantissa(): int
    {
        $data = $this->data;
        Utils::assertString($data, 'Invalid data');

        return Utils::binToBigInteger($data)->and(Utils::hexToBigInteger('7fffff'))->toInt();
    }

    public function getSign(): int
    {
        $data = $this->data;
        Utils::assertString($data, 'Invalid data');
        $sign = Utils::binToBigInteger($data)->shiftedRight(31);

        return $sign->isEqualTo(BigInteger::one()) ? -1 : 1;
    }

    private static function hex2binSafe(string $hex): string
    {
        $result = hex2bin($hex);
        if ($result === false) {
            throw new InvalidArgumentException('Invalid hex string');
        }
        return $result;
    }
}
